import React , { useState , useEffect} from 'react';
import io from 'socket.io-client';

const socket = io.connect('http://localhost:3000')
let id = 0;
function Webs(){
    const [message , setMessage]= useState([]);
    const [user , setUser] = useState([]);
    const [input , setInput] = useState('');
    const [ put , setPut] = useState('');

    useEffect(() => {
        socket.on('newMessage', (msg,usr)=> {
            setMessage(message => message.concat(msg))
            setUser( user => user.concat(usr))
        });
      }, [] );

      
      const handleChange = (e)=> {
        const {target: { value } } = e
        setInput(value)
      }

      const handleUchange = (e)=> {
        const {target: { value } } = e
        setPut(value)
      }

      const handleSubmit = (e)=> {
        e.preventDefault()
        socket.emit('message', input, put)
        setInput('')
        setPut('')
      }



  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div className="forma">
        <input id="content" type="text" name="content" onChange={handleChange} 
        value={input} placeholder="message..."/>
        </div>
        <div className="forma">
        <input id="user" type="text" name="user" onChange={handleUchange}
         value={put} placeholder="user name...."/>
        </div>
        <button type="submit" className="forma">send</button>
      </form>

      <div>
        {
          message.map((item, index) => 
          <div key={id++}>
                <h1 key ={id++}> { item } </h1>
                <div key ={id++}>{ user.filter((user, i)=> i === index).map(u => <p key ={id++}>{ u }</p>)}</div>
           </div>
          )
       }
      
      </div>

    </div>
    
  );

}

export default Webs;