import React , { useState , useEffect} from 'react';
import axios from 'axios';


function SSE(props) {

      const [message , setMessage]= useState([]);
      const [user , setUser] = useState([]);
      const [input , setInput] = useState('');
      const [ put , setPut] = useState('');

      useEffect( () => {
        const eventSource = new EventSource('http://localhost:3000/subscribe');
        eventSource.onmessage = (e)=>{
            console.log(e.data)
            const data = JSON.parse(e.data)
            setMessage(message => message.concat(data))
            setUser(user => user.concat(data))
        }
      }, [] );

      const handleChange = (e)=> {
        const {target: { value } } = e
        setInput(value)
      }

      const handleUchange = (e)=> {
        const {target: { value } } = e
        setPut(value)
      }

      const handleSubmit = (e)=> {
        e.preventDefault()
        console.log(input , put)
        axios.post('http://localhost:3000/subMsg',{'content': input, 'user': put}).then(()=>{
            setPut('')
            setInput('')
        })
      }


  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div className="forma">
        <input id="content" type="text" name="content" onChange={handleChange} 
        value={input} placeholder="message..."/>
        </div>
        <div className="forma">
        <input id="user" type="text" name="user" onChange={handleUchange}
         value={put} placeholder="user name...."/>
        </div>
        <button type="submit" className="forma">send</button>
      </form>

      <div>
        {
          message.map( (item, index) => 
          <div>
                <h1 key={item.content}> { item.content } </h1>
                <div>{ user.filter((user, i)=> i === index).map(u => <p>{ u.user }</p>)}</div>
           </div>
          )
       }
      
      </div>

    </div>
    
  );
}

export default SSE;
