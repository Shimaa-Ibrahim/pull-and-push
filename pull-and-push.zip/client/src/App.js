import React from 'react';
import './App.css';
import pull from './component/pull';
import Webs from './component/webSocket';
import SSE from './component/SSE'
 
function App() {
    

  return (
    <div>
      
      {/* <pull /> */}
 
      {/* to run websocket please uncomment */}
      {/* <Webs /> */}

      {/* to run SSE */}
      < SSE />

    </div>

   
    
  );
}

export default App;
