const cors = require('cors')
const express = require('express');
const app = express();

function SSE(){
    app.use(express.json())
    app.use(cors())

    const subscribers = {}
    app.get('/subscribe',(req,res)=>{
        const id = Math.ceil(Math.random()*10000) 
        console.log(id)
        req.on('close',()=> delete subscribers[id])
        res.writeHead(200,{
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'connection': 'keep-alive'
        })
        subscribers[id]= res
    })

    app.post('/subMsg',(req,res)=>{
        const { body } = req
        Object.keys(subscribers).forEach((id) => {
            subscribers[id].write(`data: ${JSON.stringify(body)}\n\n`)
           

        })
    })


    app.listen(3000, function () {
        console.log('listening on port 3000!');
    });

}

module.exports = {
    SSE
}