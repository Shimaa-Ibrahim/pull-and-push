const cors = require('cors')
const express = require('express');
const app = express();
const socketio = require('socket.io');
const server = require('http').Server(app);


function websocket(){

app.use(cors())

const io = socketio(server)

io.on('connection', (client)=>{
    client.on('message',(message, user) => {
        console.log(message, user);
        io.emit('newMessage', message,user)
    })
})


server.listen(3000, function () {
    console.log('listening on port 3000!');
  });

}


module.exports ={ websocket } 