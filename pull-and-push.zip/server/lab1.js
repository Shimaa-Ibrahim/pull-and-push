const cors = require('cors')
const express = require('express');
const app = express()
app.use(cors())

// const messages = []
// const users = []
// app.post('/messages', (req,res)=>{
//     res.json(messages)
// })
const subscribers = {}

app.post('/subscribe',(req,res)=>{
    const { id } = req.body
    console.log(id)
    subscribers[id]= res
})

app.post('/subMsg',(req,res)=>{
    const { body } = req

    Object.keys(subscribers).forEach((id) => {
        subscribers[id].json(body)
        delete subscribers[id]
        req.on('close',()=> delete subscribers[id])

    })
    res.status(204).end()
})


app.listen(3000, function () {
    console.log('listening on port 3000!');
  });