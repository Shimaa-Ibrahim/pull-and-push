const WS = require('./webSocket')
const SSE = require('./SSE')


// to run webSocket please uncomment this  :
//WS.websocket();

// to run SSE
SSE.SSE();